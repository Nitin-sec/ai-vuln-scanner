from datetime import datetime

def generate_html(scan_data, output_path):
    html = f"""
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ThreatMap Report</title>

<style>
body {{
    font-family: Arial;
    background: white;
    color: #222;
    padding: 40px;
}}

h1 {{
    color: #c0392b;
}}

.section {{
    margin-top: 30px;
}}

table {{
    width: 100%;
    border-collapse: collapse;
}}

th, td {{
    padding: 12px;
    border: 1px solid #ddd;
}}

th {{
    background: #2c3e50;
    color: white;
}}

.severity-medium {{ color: orange; font-weight: bold; }}
.severity-info {{ color: #3498db; }}

</style>
</head>

<body>

<h1>ThreatMap Infra — VAPT Report</h1>

<div class="section">
<strong>Target:</strong> {scan_data['target']}<br>
<strong>Generated:</strong> {datetime.now()}
</div>

<div class="section">
<h2>Findings</h2>

<table>
<tr>
<th>Host</th>
<th>Port</th>
<th>Service</th>
</tr>
"""

    for host, data in scan_data["hosts"].items():
        for port in data["open_ports"]:
            html += f"""
<tr>
<td>{host}</td>
<td>{port['port']}</td>
<td>{port['service']}</td>
</tr>
"""

    html += """
</table>
</div>

</body>
</html>
"""

    with open(output_path, "w") as f:
        f.write(html)

    return output_path
