import webbrowser
import os

def open_file(path):
    if not os.path.exists(path):
        print(f"[!] File not found: {path}")
        return

    print(f"[+] Opening report in browser: {path}")
    webbrowser.open(f"file://{path}")
